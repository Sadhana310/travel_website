
from flask import Flask, render_template

app = Flask(__name__)

# Sample destination data
destinations = [
    {
        "id": 1,
        "name": "Similan Islands, Thailand",
        "country": "Thailand, Asia",
        "rating": "4.8",
        "price": "$160 / 4 days",
        "image": "similan.png",
        "reviews": "1,230 reviews",
        "description": "Known for crystal-clear waters, coral reefs, and white sand beaches."
    }
]

@app.route('/')
def index():
    return render_template("index.html", destinations=destinations)

@app.route('/destination/<int:id>')
def detail(id):
    dest = next((d for d in destinations if d["id"] == id), None)
    return render_template("detail.html", destination=dest)

if __name__ == '__main__':
    app.run(debug=True)
